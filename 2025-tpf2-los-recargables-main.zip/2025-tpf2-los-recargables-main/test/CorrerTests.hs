import Spec
import PdePreludat

main :: IO ()
main = correrTests