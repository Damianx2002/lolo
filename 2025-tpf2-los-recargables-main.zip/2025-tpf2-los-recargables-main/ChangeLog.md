# Changelog for baseHaskell

## Unreleased changes
